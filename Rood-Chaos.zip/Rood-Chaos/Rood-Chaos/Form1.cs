﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;

namespace Rood_Chaos
{
    public partial class Chaos : Form
    {
        /*
        Opdracht:
        Maak een programma dat in staat is om in een relatief kleine tekst(hooguit 1 A4 tje) die geschreven
        is met een bepaald lettertype te veranderen in een tekst waar per letterteken een willekeurig
        verschillend lettertype gebruikt wordt(een beetje het effect van 'losgeldbrieven').
        Arrays zijn daarbij onvermijdbaar.

        Werkwijze:
        - Interface gemaakt en meeste code geschreven. Was iets van drie kwartier.
        - Problemen met opmaak van output-veld. rtbOutput.Font verandert alles.
            - Kwam er later achter dat random van systeemklok niet random genoeg was. Meestal waren er maar
              1 of 2 fonts als het 1 zin moest omzetten.
        - Nu werkt het dankzij AppendText. Kostte ruim 2 uur om dat te vinden. Frustrerend. Veel websites
          zeiden dat het niet mogelijk was. Ik vermoedde wel dat er een manier was om telkens een char bij
          te voegen (en dan de font te kiezen). Maar ik kon de manier niet vinden. Lastig op te zoeken, ook,
          qua zoekopdracht.
        - Al is nu echter dat het met een counter alle fonts in de List afgaat. Wat voorspelbaar is, en dus
          niet willekeurig zoals de opdracht.
        - Verder gezocht. Bleek dat "Random random = new Random();" buiten de foreach zetten, wel random
          genoeg is. Ik vermoed omdat dit de seed registreert? En iedere keer dezelfde seed, met dezelfde
          vervolgberekeningen(?) geven heel kort na elkaar dezelfde uitkomst?
        - Leek me het meest praktisch om een aantal fonts te kiezen die de meeste mensen wel zullen hebben.
          En die ook enigszins verschillend zijn, zodat het resultaat duidelijk zichtbaar is. Grootte 8
          vond ik wel genoeg, ook.
        - In theorie kan de input oneindig groot worden. Ongeveer 1 A4 is best vaag. Ik zou het kunnen
          beperken door een limiet in charArrayTekst te zetten.
        */
        
        public Chaos()
        {
            InitializeComponent();
            
            fontList.Add("Arial");
            fontList.Add("Calibri");
            fontList.Add("Century");
            fontList.Add("Comic Sans MS");
            fontList.Add("Impact");
            fontList.Add("Times New Roman");
            fontList.Add("Verdana");
        }
        private List<string> fontList = new List<string>();

        private void btnChaos_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            rtbOutput.Text = "";
            char[] charArrayTekst = rtbInput.Text.ToCharArray();
            //string test = charArrayTekst[0].ToString();
            foreach (var teken in charArrayTekst)
            {
                int teller = random.Next(0, 7);
                rtbOutput.SelectionFont = new Font(fontList[teller], 8);
                rtbOutput.AppendText(Convert.ToString(teken));
            }
        }
    }
}
