﻿
namespace Rood_Chaos
{
    partial class Chaos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Chaos));
            this.btnChaos = new System.Windows.Forms.Button();
            this.rtbInput = new System.Windows.Forms.RichTextBox();
            this.rtbOutput = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnChaos
            // 
            this.btnChaos.BackColor = System.Drawing.Color.Snow;
            this.btnChaos.Location = new System.Drawing.Point(344, 257);
            this.btnChaos.Name = "btnChaos";
            this.btnChaos.Size = new System.Drawing.Size(97, 47);
            this.btnChaos.TabIndex = 1;
            this.btnChaos.Text = "Chaos!!!";
            this.btnChaos.UseVisualStyleBackColor = false;
            this.btnChaos.Click += new System.EventHandler(this.btnChaos_Click);
            // 
            // rtbInput
            // 
            this.rtbInput.BackColor = System.Drawing.Color.PeachPuff;
            this.rtbInput.Location = new System.Drawing.Point(12, 12);
            this.rtbInput.Name = "rtbInput";
            this.rtbInput.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rtbInput.Size = new System.Drawing.Size(300, 537);
            this.rtbInput.TabIndex = 3;
            this.rtbInput.Text = resources.GetString("rtbInput.Text");
            // 
            // rtbOutput
            // 
            this.rtbOutput.BackColor = System.Drawing.Color.PeachPuff;
            this.rtbOutput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbOutput.Location = new System.Drawing.Point(472, 12);
            this.rtbOutput.Name = "rtbOutput";
            this.rtbOutput.ReadOnly = true;
            this.rtbOutput.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rtbOutput.Size = new System.Drawing.Size(300, 537);
            this.rtbOutput.TabIndex = 3;
            this.rtbOutput.Text = "";
            // 
            // Chaos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Coral;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.rtbOutput);
            this.Controls.Add(this.rtbInput);
            this.Controls.Add(this.btnChaos);
            this.Name = "Chaos";
            this.Text = "Chaotische lettertypes";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnChaos;
        private System.Windows.Forms.RichTextBox rtbInput;
        private System.Windows.Forms.RichTextBox rtbOutput;
    }
}

