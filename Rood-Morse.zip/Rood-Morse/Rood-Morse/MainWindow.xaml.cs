﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;

namespace Rood_Morse
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /*
        Opdracht:
        Schrijf een programma waarmee je (Nederlandse) tekst kunt invoeren en deze wordt dan vertaald in
        Morsecode. Zorg ervoor dat de Morse code weer terug vertaald kan worden naar de oorspronkelijke
        tekst.

        Geplande werkwijze:
        - GUI maken
        - Een of ander array/list maken met char letter en morsecode combinaties.
        - RTF contents pakken en omzetten naar char[] om daarmee te zoeken in combinatielijst
        - per char de morsecode printen
        - Nog iets aan schrijfwijzes doen na teruggaan van morse naar tekst? Morse heeft alleen hoofdletters.

        Problemen:
        - wist aanvankelijk niet meer dat een char met enkele aanhalingstekens was.
        - List werkte niet naar wens. Dictionary wel.
        - Kwam er maar niet uit hoe ik kon zoeken op teken uit char[] in dictionary, uiteindelijk
        maar de methods van dictionary langsgegaan om te kijken wat nou wat deed.
        - Beslissen hoe ik scheidingstekens tussen morsecodes plaats. Anders is de weg terug niet te doen.
        - mijnDictionary heeft de letters als key en de morse als value. Met TryGetValue moet ik de key opgeven
        om de value te krijgen. En TryGetKey bestaat niet. Beste dus om met code de value en key van plaats te
        laten wisselen, zodat ik maar 1 dictionary hoef in te voeren. Dan hoef ik ook niet 2 dictionaries te
        editen (en controleren).

        Eventueel nog mogelijk:
        - Nog iets aan schrijfwijzes doen na teruggaan van morse naar tekst? Morse heeft alleen hoofdletters. Al
        kan men zo wel zien dat ik niet de code uit box 1 letterlijk kopieer.
        - Wellicht morse-code laten afspelen met een knop? Al was dit niet gevraagd. En ik heb geen .wav-bestanden
        met een korte of lange toon.

        Het was best frustrerend, omdat ik het aanvankelijk niet goed werkend kon krijgen. En ik wist niet goed
        hoe ik het probleem moest verwoorden. Wat het nogal lastig maakt met een zoekmachine.
        */

        public MainWindow()
        {
            InitializeComponent();

            //Morsealfabet op Wikipedia gevonden en omgezet naar , en -
            mijnDictionary.Add('A', ",-");
            mijnDictionary.Add('B', "-,,,");
            mijnDictionary.Add('C', "-,-,");
            mijnDictionary.Add('D', "-,,");
            mijnDictionary.Add('E', ",");
            mijnDictionary.Add('F', ",,-,");
            mijnDictionary.Add('G', "--,");
            mijnDictionary.Add('H', ",,,,");
            mijnDictionary.Add('I', ",,");
            mijnDictionary.Add('J', ",---");
            mijnDictionary.Add('K', "-,-");
            mijnDictionary.Add('L', ",-,,");
            mijnDictionary.Add('M', "--");
            mijnDictionary.Add('N', "-,");
            mijnDictionary.Add('O', "---");
            mijnDictionary.Add('P', ",--,");
            mijnDictionary.Add('Q', "--,-");
            mijnDictionary.Add('R', ",-,");
            mijnDictionary.Add('S', ",,,");
            mijnDictionary.Add('T', "-");
            mijnDictionary.Add('U', ",,-");
            mijnDictionary.Add('V', ",,,-");
            mijnDictionary.Add('W', ",--");
            mijnDictionary.Add('X', "-,,-");
            mijnDictionary.Add('Y', "-,--");
            mijnDictionary.Add('Z', "--,,");
            mijnDictionary.Add('0', "-----");
            mijnDictionary.Add('1', ",----");
            mijnDictionary.Add('2', ",,---");
            mijnDictionary.Add('3', ",,,--");
            mijnDictionary.Add('4', ",,,,-");
            mijnDictionary.Add('5', ",,,,,");
            mijnDictionary.Add('6', "-,,,,");
            mijnDictionary.Add('7', "--,,,");
            mijnDictionary.Add('8', "---,,");
            mijnDictionary.Add('9', "----,");
            mijnDictionary.Add('.', ",-,-,-");
            mijnDictionary.Add(',', "--,,--");
            mijnDictionary.Add('?', ",,--,,");
            mijnDictionary.Add('!', "-,-,--");
            mijnDictionary.Add('-', "-,,,,=");
            mijnDictionary.Add('/', "-,,-,");
            mijnDictionary.Add(':', "---,,,");
            mijnDictionary.Add('\'', ",----,");
            mijnDictionary.Add(')', "-,--,-");
            mijnDictionary.Add(';', "-,-,-");
            mijnDictionary.Add('(', "-,--,");
            mijnDictionary.Add('=', "-,,,-");
            mijnDictionary.Add('@', ",--,-,");
            mijnDictionary.Add('&', ",-,,,");
            mijnDictionary.Add(' ', ".");

            //Deze regel kwam ik online tegen. Ik kwam er niet uit hoe het anders moest. Hier was ik zelf waarschijnlijk
            //niet opgekomen. Deze functionaliteit was nodig om het werkend te krijgen. Dus deze regel is dan knip- en
            //plakwerk, neem ik aan? Geen idee hoe ik het anders had moeten oplossen.
            //Of misschien een omweg met extra variables waarbij ik mijnDictionary.Key aan de ene var toewijs. En
            //mijnDictionary.Value aan de andere. Dan met foreach mijnDictionaryTerug bouwen?
            //Al zijn .Key en .Value niet direct te bereiken.
            mijnDictionaryTerug = mijnDictionary.ToDictionary(x => x.Value, x => x.Key);

        }
        private Dictionary<char, string> mijnDictionary = new Dictionary<char, string>();
        private Dictionary<string, char> mijnDictionaryTerug = new Dictionary<string, char>();

        private string Tekst(RichTextBox invoer)
        {
            TextRange alleTekst = new TextRange(
                invoer.Document.ContentStart,
                invoer.Document.ContentEnd
                );
            return alleTekst.Text;
        }

        private void ButtonNaarMorse_Click(object sender, RoutedEventArgs e)
        {
            string tekst = Tekst(RtfTekst);
            tekst = tekst.ToUpper();        //Morse-alfabet op wikipedia had enkel hoofdletters. Dit convert makkelijker.
            tekst.Trim();                   //Wellicht overbodig. Maar voor uitlijning mooier.
            char[] charArrayTekst = new char[tekst.Length];
            charArrayTekst = tekst.ToCharArray();

            //foreach letterteken, print de morsecode + een spatie
            TextBoxMorse.Text = "";
            foreach (var teken in charArrayTekst)
            {
                mijnDictionary.TryGetValue(teken, out string uitvoer);
                TextBoxMorse.Text += uitvoer + " ";
            }
        }

        private void ButtonNaarTekst_Click(object sender, RoutedEventArgs e)
        {
            string morse = TextBoxMorse.Text;
            morse.Trim();                                       //Ik wil geen extra spaties er voor/na.
            string[] stringArrayMorse = morse.Split(' ');       //Splits op basis van de tussenspaties
            //Zodat iedere entry in stringArrayMorse de morsecode van 1 teken is.
            TextBoxTerugNaarTekst.Text = "";
            //foreach morsecode van 1 teken, print het letterteken.
            foreach (var morseVan1Teken in stringArrayMorse)
            {
                mijnDictionaryTerug.TryGetValue(morseVan1Teken, out char uitvoer);
                TextBoxTerugNaarTekst.Text += uitvoer;
            }
        }
        //Omdat een spatie hier in morse geprint wordt als een punt, kan ik de morse splitsen op spaties en toch de
        //oorspronkelijke spaties binnen de zin(nen) behouden.
        //"e e" wordt ", . ," wordt "E E"
    }
}
