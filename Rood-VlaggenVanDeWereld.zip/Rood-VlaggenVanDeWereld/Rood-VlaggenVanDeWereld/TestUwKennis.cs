﻿using Rood_VlaggenVanDeWereld.Properties;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Rood_VlaggenVanDeWereld
{
    public partial class TestUwKennis : Form
    {
        private Dictionary<string, Bitmap> Vlaggen = new Dictionary<string, Bitmap>();

        public TestUwKennis()
        {
            InitializeComponent();

            Vlaggen.Add("België", Resources.Belgie);
            Vlaggen.Add("Bulgarije", Resources.Bulgarije);
            Vlaggen.Add("Cyprus", Resources.Cyprus);
            Vlaggen.Add("Denemarken", Resources.Denemarken);
            Vlaggen.Add("Duitsland", Resources.Duitsland);
            Vlaggen.Add("Estland", Resources.Estland);
            Vlaggen.Add("Finland", Resources.Finland);
            Vlaggen.Add("Frankrijk", Resources.Frankrijk);
            Vlaggen.Add("Griekenland", Resources.Griekenland);
            Vlaggen.Add("Hongarije", Resources.Hongarije);
            Vlaggen.Add("Ierland", Resources.Ierland);
            Vlaggen.Add("Italië", Resources.Italie);
            Vlaggen.Add("Kroatië", Resources.Kroatie);
            Vlaggen.Add("Letland", Resources.Letland);
            Vlaggen.Add("Litouwen", Resources.Litouwen);
            Vlaggen.Add("Luxemburg", Resources.Luxemburg);
            Vlaggen.Add("Malta", Resources.Malta);
            Vlaggen.Add("Nederland", Resources.Nederland);
            Vlaggen.Add("Oostenrijk", Resources.Oostenrijk);
            Vlaggen.Add("Polen", Resources.Polen);
            Vlaggen.Add("Portugal", Resources.Portugal);
            Vlaggen.Add("Roemenié", Resources.Roemenie);
            Vlaggen.Add("Slovenië", Resources.Slovenie);
            Vlaggen.Add("Slowakije", Resources.Slowakije);
            Vlaggen.Add("Spanje", Resources.Spanje);
            Vlaggen.Add("Tsjechië", Resources.Tsjechie);
            Vlaggen.Add("Zweden", Resources.Zweden);
        }

        private int antwoordBij;
        private int kiesLand = 0;
        private int foutAntwoord1;
        private int foutAntwoord2;
        private int score = 0;
        private int beurt = 0;

        private void ButtonNaarHoofdmenu_Click(object sender, System.EventArgs e)
        {
            //Form f = new Hoofdmenu();
            //f.Show();
            //Ik had eerst bovenstaande. Maar dat opende dan telkens een nieuw Hoofdmenu form.
            //Waardoor het geheugengebruik telkens toenam.
            //Onderstaande foreach + if op internet gevonden.
            //Kwam er niet uit hoe ik de inhoud van Application.OpenForms kon pakken.
            //Of hoe ik de visibility van Hoofdmenu kon aanpassen naar true.
            foreach (Form open in Application.OpenForms)
            {
                if (open is Hoofdmenu)
                {
                    open.Show();
                    break;
                }
            }
            //Bovenstaande 7 regels dus knip- en plakwerk.
            this.Close();
        }

        private int WelkeButton()
        {
            Random rand = new Random();
            int getal = rand.Next(1, 4);
            return getal;
        }

        private int WelkLand()
        {
            Random rand = new Random();
            int getal = rand.Next(Vlaggen.Count);
            return getal;
        }

        private int Fout1()
        {
            int getal = WelkLand();
            //Het is in theorie mogelijk dat een van de foute antwoorden hetzelfde land kiest als het juiste antwoord.
            //Dit zou dat onmogelijk moeten maken? -> Doe het 1 keer, zolang intern getal == correct antwoord, rol opnieuw.
            //Pas zodra getal != correct antwoord, return getal.
            while (getal == kiesLand)
            {
                getal = WelkLand();
            }
            return getal;
        }
        private int Fout2()
        {
            int getal = WelkLand();
            //Dit controleert dus op == correct antwoord en == foutAntwoord1.
            while (getal == kiesLand ||
                getal == foutAntwoord1)
            {
                getal = WelkLand();
            }
            return getal;
        }

        private void Score()
        {
            LabelScore.Text = ("U heeft er " + score + " van de 20 goed.");
            LaatsteVraag();
        }

        private void LaatsteVraag()
        {
            if (beurt == 20)
            {
                //Zodra alle vragen gesteld zijn, maak alles onzichtbaar, en stop de timer.
                LabelVraag.Visible = false;
                PictureBoxTestUwKennis.Visible = false;
                ProgressTijd.Visible = false;
                TimerVolgendeVlag.Stop();
                ButtonAntwoord1.Visible = false;
                ButtonAntwoord2.Visible = false;
                ButtonAntwoord3.Visible = false;
            }
        }

        private void TimerVolgendeVlag_Tick(object sender, EventArgs e)
        {
            if (beurt <= 20)
            {
                if (ProgressTijd.Value == 0)
                {
                    ProgressTijd.Value = ProgressTijd.Maximum;
                    antwoordBij = WelkeButton();
                    kiesLand = WelkLand();
                    //Ik kan ook rechtstreeks ElementAt(Fout1()).Key doen, maar dit is leesbaarder?
                    foutAntwoord1 = Fout1();
                    foutAntwoord2 = Fout2();
                    if (antwoordBij == 1)
                    {
                        PictureBoxTestUwKennis.Image = Vlaggen.ElementAt(kiesLand).Value;
                        ButtonAntwoord1.Text = Vlaggen.ElementAt(kiesLand).Key;
                        ButtonAntwoord2.Text = Vlaggen.ElementAt(foutAntwoord1).Key;
                        ButtonAntwoord3.Text = Vlaggen.ElementAt(foutAntwoord2).Key;
                    }
                    else if (antwoordBij == 2)
                    {
                        PictureBoxTestUwKennis.Image = Vlaggen.ElementAt(kiesLand).Value;
                        ButtonAntwoord1.Text = Vlaggen.ElementAt(foutAntwoord1).Key;
                        ButtonAntwoord2.Text = Vlaggen.ElementAt(kiesLand).Key;
                        ButtonAntwoord3.Text = Vlaggen.ElementAt(foutAntwoord2).Key;
                    }
                    else if (antwoordBij == 3)
                    {
                        PictureBoxTestUwKennis.Image = Vlaggen.ElementAt(kiesLand).Value;
                        ButtonAntwoord1.Text = Vlaggen.ElementAt(foutAntwoord1).Key;
                        ButtonAntwoord2.Text = Vlaggen.ElementAt(foutAntwoord2).Key;
                        ButtonAntwoord3.Text = Vlaggen.ElementAt(kiesLand).Key;
                    }
                    
                    beurt++;
                    LabelVraag.Text = beurt + ". Van welk land is deze vlag?";
                }
                else
                {
                    ProgressTijd.PerformStep();
                }
            }
        }

        private void LeegButtons()
        {
            ButtonAntwoord1.Text = "";
            ButtonAntwoord2.Text = "";
            ButtonAntwoord3.Text = "";
        }

        private void ButtonAntwoord1_Click(object sender, System.EventArgs e)
        {
            //Als antwoordBij == 1, staat dus onder deze knop het goede antwoord.
            if (antwoordBij == 1)
            {
                score++;
            }
            Score();
            ProgressTijd.Value = 0;
        }

        private void ButtonAntwoord2_Click(object sender, System.EventArgs e)
        {
            if (antwoordBij == 2)
            {
                score++;
            }
            Score();
            ProgressTijd.Value = 0;
        }

        private void ButtonAntwoord3_Click(object sender, System.EventArgs e)
        {
            if (antwoordBij == 3)
            {
                score++;
            }
            Score();
            ProgressTijd.Value = 0;
        }
    }
}
