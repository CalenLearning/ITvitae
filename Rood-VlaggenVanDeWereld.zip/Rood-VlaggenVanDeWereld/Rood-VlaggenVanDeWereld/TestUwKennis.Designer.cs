﻿namespace Rood_VlaggenVanDeWereld
{
    partial class TestUwKennis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ButtonNaarHoofdmenu = new System.Windows.Forms.Button();
            this.ButtonAntwoord1 = new System.Windows.Forms.Button();
            this.ButtonAntwoord2 = new System.Windows.Forms.Button();
            this.ButtonAntwoord3 = new System.Windows.Forms.Button();
            this.LabelVraag = new System.Windows.Forms.Label();
            this.PictureBoxTestUwKennis = new System.Windows.Forms.PictureBox();
            this.TimerVolgendeVlag = new System.Windows.Forms.Timer(this.components);
            this.ProgressTijd = new System.Windows.Forms.ProgressBar();
            this.LabelScore = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxTestUwKennis)).BeginInit();
            this.SuspendLayout();
            // 
            // ButtonNaarHoofdmenu
            // 
            this.ButtonNaarHoofdmenu.Location = new System.Drawing.Point(12, 12);
            this.ButtonNaarHoofdmenu.Name = "ButtonNaarHoofdmenu";
            this.ButtonNaarHoofdmenu.Size = new System.Drawing.Size(122, 23);
            this.ButtonNaarHoofdmenu.TabIndex = 4;
            this.ButtonNaarHoofdmenu.Text = "<- Naar Hoofdmenu";
            this.ButtonNaarHoofdmenu.UseVisualStyleBackColor = true;
            this.ButtonNaarHoofdmenu.Click += new System.EventHandler(this.ButtonNaarHoofdmenu_Click);
            // 
            // ButtonAntwoord1
            // 
            this.ButtonAntwoord1.Location = new System.Drawing.Point(512, 191);
            this.ButtonAntwoord1.Name = "ButtonAntwoord1";
            this.ButtonAntwoord1.Size = new System.Drawing.Size(123, 40);
            this.ButtonAntwoord1.TabIndex = 6;
            this.ButtonAntwoord1.Text = "Antwoord 1";
            this.ButtonAntwoord1.UseVisualStyleBackColor = true;
            this.ButtonAntwoord1.Click += new System.EventHandler(this.ButtonAntwoord1_Click);
            // 
            // ButtonAntwoord2
            // 
            this.ButtonAntwoord2.Location = new System.Drawing.Point(512, 260);
            this.ButtonAntwoord2.Name = "ButtonAntwoord2";
            this.ButtonAntwoord2.Size = new System.Drawing.Size(123, 40);
            this.ButtonAntwoord2.TabIndex = 6;
            this.ButtonAntwoord2.Text = "Antwoord 2";
            this.ButtonAntwoord2.UseVisualStyleBackColor = true;
            this.ButtonAntwoord2.Click += new System.EventHandler(this.ButtonAntwoord2_Click);
            // 
            // ButtonAntwoord3
            // 
            this.ButtonAntwoord3.Location = new System.Drawing.Point(512, 329);
            this.ButtonAntwoord3.Name = "ButtonAntwoord3";
            this.ButtonAntwoord3.Size = new System.Drawing.Size(123, 40);
            this.ButtonAntwoord3.TabIndex = 6;
            this.ButtonAntwoord3.Text = "Antwoord 3";
            this.ButtonAntwoord3.UseVisualStyleBackColor = true;
            this.ButtonAntwoord3.Click += new System.EventHandler(this.ButtonAntwoord3_Click);
            // 
            // LabelVraag
            // 
            this.LabelVraag.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelVraag.Location = new System.Drawing.Point(92, 99);
            this.LabelVraag.Name = "LabelVraag";
            this.LabelVraag.Size = new System.Drawing.Size(600, 37);
            this.LabelVraag.TabIndex = 7;
            this.LabelVraag.Text = "Van welk land is deze vlag?";
            this.LabelVraag.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PictureBoxTestUwKennis
            // 
            this.PictureBoxTestUwKennis.InitialImage = null;
            this.PictureBoxTestUwKennis.Location = new System.Drawing.Point(149, 191);
            this.PictureBoxTestUwKennis.Name = "PictureBoxTestUwKennis";
            this.PictureBoxTestUwKennis.Size = new System.Drawing.Size(200, 150);
            this.PictureBoxTestUwKennis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBoxTestUwKennis.TabIndex = 8;
            this.PictureBoxTestUwKennis.TabStop = false;
            // 
            // TimerVolgendeVlag
            // 
            this.TimerVolgendeVlag.Enabled = true;
            this.TimerVolgendeVlag.Interval = 50;
            this.TimerVolgendeVlag.Tick += new System.EventHandler(this.TimerVolgendeVlag_Tick);
            // 
            // ProgressTijd
            // 
            this.ProgressTijd.Location = new System.Drawing.Point(149, 356);
            this.ProgressTijd.Name = "ProgressTijd";
            this.ProgressTijd.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ProgressTijd.Size = new System.Drawing.Size(200, 13);
            this.ProgressTijd.Step = -1;
            this.ProgressTijd.TabIndex = 9;
            // 
            // LabelScore
            // 
            this.LabelScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelScore.Location = new System.Drawing.Point(92, 415);
            this.LabelScore.Name = "LabelScore";
            this.LabelScore.Size = new System.Drawing.Size(600, 37);
            this.LabelScore.TabIndex = 10;
            this.LabelScore.Text = "Uw score is 0/20.";
            this.LabelScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TestUwKennis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.LabelScore);
            this.Controls.Add(this.ProgressTijd);
            this.Controls.Add(this.PictureBoxTestUwKennis);
            this.Controls.Add(this.LabelVraag);
            this.Controls.Add(this.ButtonAntwoord3);
            this.Controls.Add(this.ButtonAntwoord2);
            this.Controls.Add(this.ButtonAntwoord1);
            this.Controls.Add(this.ButtonNaarHoofdmenu);
            this.Name = "TestUwKennis";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Leer de vlaggen van de EU";
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxTestUwKennis)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ButtonNaarHoofdmenu;
        private System.Windows.Forms.Button ButtonAntwoord1;
        private System.Windows.Forms.Button ButtonAntwoord2;
        private System.Windows.Forms.Button ButtonAntwoord3;
        private System.Windows.Forms.PictureBox PictureBoxTestUwKennis;
        private System.Windows.Forms.Timer TimerVolgendeVlag;
        private System.Windows.Forms.ProgressBar ProgressTijd;
        private System.Windows.Forms.Label LabelScore;
        private System.Windows.Forms.Label LabelVraag;
    }
}