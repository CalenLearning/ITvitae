﻿using System;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace Rood_VlaggenVanDeWereld
{
    public partial class Hoofdmenu : Form
    {
        public Hoofdmenu()
        {
            InitializeComponent();
        }

        private void ButtonOverzicht_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form f = new OverzichtVlaggen();
            f.Show();
        }

        private void ButtonTestUwKennis_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form f = new TestUwKennis();
            f.Show();
        }

        /*
        Opdracht:
        Maak een programma waarmee de gebruiker (a) alle vlaggen van de wereld kan bekijken (b) zich in
        het herkennen van die vlaggen kan oefenen.

        Geplande werkwijze:
        - Uitzoeken hoe ik plaatjes kan gebruiken
        - Een verzameling vlaggen van wikipedia kopiëren.
        - Interface bedenken.
            - Twee delen
                1. Overzicht om te bestuderen
                   Scherm gevuld met alle vlaggen en bijbehorende namen
                2. Testomgeving
                   Grote vlag links, dynamische invoer
                   3 knoppen rechts met willekeurige naam van land per knop, waarvan 1 correct.
        - Op een of andere manier naam aan vlag koppelen.
        - Score? Of na x vragen de test eindigen?
        - Resetknop? Testomgeving opnieuw laten beginnen na resetknop, wel (wegens spieken).

        Werkwijze:
        - Form-document gemaakt (werd gebruikt in filmpje met uitleg over plaatjes).
        - Alle vlaggen hele wereld lijkt me een beetje overdreven. De opdracht is wel alle vlaggen van
          de wereld. Maar als het me ~30 seconden kost per vlag opslaan, dan ben ik met ~200 vlaggen
          ruim anderhalf uur bezig. Functioneel gezien is dit een leeropdracht, dus lijken de EU-vlaggen
          mij ook voldoende.
        - 27 vlaggen opslaan als .PNG. Meteen maar alle ë als gewone e geschreven.
        - Controle of ik 27 .PNG-bestanden heb.
          127 breed en 110 hoog zijn grootste afmetingen.
            - Uiteindelijk images laten resizen. Bestandsgroottes zijn minimaal, dus bronbestanden zo
              gelaten.
        - Voorzie probleem als ik een hoofdmenu heb, en twee aparte schermen met of overzicht, of test.
          Visibility aanpassen van dingen die allemaal in dezelfde form staan, wordt rommelig.
        - Opgezocht of ik ook een form-bestand per groep objecten kan doen. Lijkt in theorie te kunnen.
          Wellicht wordt resetten hierdoor makkelijker, omdat ik simpelweg naar "hoofdmenu" kan.
        - Gepuzzel hoe ik een ander form kan openen.
        - OverzichtVlaggen-form gevuld. Alles uitgelijnd. Ook knop terug naar het hoofdmenu toegevoegd.
          Lijkt erop dat ë en dergelijke wel ondersteund zouden worden.
        - Knop terug naar het hoofdmenu gekopieerd naar TestUwKennis. Onder button zelfde code toegevoegd
          als bij OverzichtVlaggen. Wellicht beter om in een method te zetten en die dan op twee plekken
          aanroepen? Maar ik doe drie dingen: nieuw form maken, die openen, en huidige form sluiten.
          Handigste om maar 1 ding per method te doen. Dus dit is korter?
        - Bedenken hoe ik de vlaggen en antwoorden wil selecteren.
            - Random nummer is handigste, denk ik.
            - if nummer x && antwoord nummer x dan score++
            - Andere twee antwoorden een willekeurig ander random nummer.
            - Dus ook random toewijzen welke antwoordknop het juiste antwoord heeft.
            - max 20 vragen? Op die manier hou je niet 1 antwoord in gedachten over.
                - Mogelijkheid om opnieuw te beginnen na 20.
        - Best lang gezocht hoe ik een random nummer kon gebruiken om te selecteren welke combinatie het
          uit de dictionary ging pakken. Bleek uiteindelijk dat ik simpelweg Vlaggen.ElementAt(kiesLand).Key
          kon doen. Oftewel .Key en .Value erachter zetten. Was sneller geweest om twee dicionaries te doen.
          <getal, naam>  en <getal, bitmap>. En dan met trygetvalue. Maar ik wilde dit proberen.
          Ook handiger om entries toe te voegen. Add(naam, bitmap), koppelt meteen naam aan bitmap.
        - Voortgangsbalk toegevoegd. Begint nu bij max value, loopt leeg (standaard was andersom). Grappig.
          Idee is om daarmee te laten zien hoelang je nog hebt totdat de volgende vlag verschijnt.
        - RAM-gebruik gaat telkens iets omhoog als ik van form wissel. Blijkt niet aan telkens een nieuw
          hoofdmenu-form te liggen. Weet niet waaraan dan wel.
        - random class is niet random genoeg. Het print meerdere keren achter elkaar wel een nieuwe
          vlag/antwoord-combinatie, maar consequent 3+ keer achter elkaar op dezelfde button.
            - maxvalue van progressbar aanpassen naar minder dan een hele seconde helpt wel, maar
              niet genoeg.
            - Probleem verdween nadat ik WelkeButton() had gemaakt. Wellicht omdat een andere method
              opvragen minieme variaties heeft in reactietijd?
              (WelkeButton() stond eerst in de timer event.)
        - Het meeste werkt. Er is nog 1 bug, die ik niet kan vinden na een paar uur zoeken/proberen.
          Soms vraagt het twee keer achter elkaar dezelfde vlag. Het keurt echter maar soms het
          goede antwoord goed.
        - Twee dagen later bug gevonden. Steeds de code iets aangepast om een ander deel te testen.
        Dacht aanvankelijk dat de button soms de klik niet registreerde, maar dat was onlogisch.
        private int WelkeButton()
        {
            Random rand = new Random();
            int getal = rand.Next(1, 4);
            return getal;
        }
        Daar stond eerst "int getal = rand.Next(0, 4);". Waardoor het soms 0 is. En als ik dan score++ doe
        bij waarde 1, 2 of 3, gebeurt er natuurlijk niets bij 0.
        Blijft verwarrend dat het in feite 1 tot 4 betekent. In plaats van alles tussen de gegeven cijfers, of
        1 t/m 4.
        */
    }
}
