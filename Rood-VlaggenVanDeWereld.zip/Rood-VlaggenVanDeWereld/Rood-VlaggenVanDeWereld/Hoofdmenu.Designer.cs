﻿namespace Rood_VlaggenVanDeWereld
{
    partial class Hoofdmenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonOverzicht = new System.Windows.Forms.Button();
            this.ButtonTestUwKennis = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ButtonOverzicht
            // 
            this.ButtonOverzicht.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonOverzicht.Location = new System.Drawing.Point(147, 332);
            this.ButtonOverzicht.Name = "ButtonOverzicht";
            this.ButtonOverzicht.Size = new System.Drawing.Size(150, 75);
            this.ButtonOverzicht.TabIndex = 0;
            this.ButtonOverzicht.Text = "Overzicht";
            this.ButtonOverzicht.UseVisualStyleBackColor = true;
            this.ButtonOverzicht.Click += new System.EventHandler(this.ButtonOverzicht_Click);
            // 
            // ButtonTestUwKennis
            // 
            this.ButtonTestUwKennis.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonTestUwKennis.Location = new System.Drawing.Point(488, 332);
            this.ButtonTestUwKennis.Name = "ButtonTestUwKennis";
            this.ButtonTestUwKennis.Size = new System.Drawing.Size(150, 75);
            this.ButtonTestUwKennis.TabIndex = 1;
            this.ButtonTestUwKennis.Text = "Test uw kennis";
            this.ButtonTestUwKennis.UseVisualStyleBackColor = true;
            this.ButtonTestUwKennis.Click += new System.EventHandler(this.ButtonTestUwKennis_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(191, 154);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(395, 125);
            this.label1.TabIndex = 2;
            this.label1.Text = "Klik op de linkerknop voor een overzicht\r\nvan alle vlaggen van de EU.\r\n\r\nKlik op " +
    "de rechterknop om te kijken\r\nhoeveel u er goed onthouden heeft.";
            // 
            // Hoofdmenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ButtonTestUwKennis);
            this.Controls.Add(this.ButtonOverzicht);
            this.Name = "Hoofdmenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Leer de vlaggen van de EU";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonOverzicht;
        private System.Windows.Forms.Button ButtonTestUwKennis;
        private System.Windows.Forms.Label label1;
    }
}

