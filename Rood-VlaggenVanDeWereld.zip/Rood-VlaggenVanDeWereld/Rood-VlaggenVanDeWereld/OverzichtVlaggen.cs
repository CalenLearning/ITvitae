﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rood_VlaggenVanDeWereld
{
    public partial class OverzichtVlaggen : Form
    {
        public OverzichtVlaggen()
        {
            InitializeComponent();
        }

        private void ButtonNaarHoofdmenu_Click(object sender, EventArgs e)
        {
            //Form f = new Hoofdmenu();
            //f.Show();
            //Ik had eerst bovenstaande. Maar dat opende dan telkens een nieuwe Hoofdmenu form.
            //Waardoor het geheugengebruik telkens toenam.
            //Onderstaande foreach + if op internet gevonden.
            //Kwam er niet uit hoe ik de inhoud van Application.OpenForms kon pakken.
            //Of hoe ik de visibility van Hoofdmenu kon aanpassen naar true.
            foreach (Form open in Application.OpenForms)
            {
                if (open is Hoofdmenu)
                {
                    open.Show();
                    break;
                }
            }
            //Bovenstaande 7 regels dus knip- en plakwerk.
            this.Close();
        }
    }
}
