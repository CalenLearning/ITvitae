﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RoodLetterfrequenties
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /*
        Ontwerpidee:
        Inputbron mogelijk verschillende talen.
            Website scrape geeft ook de html en ccs code. Vertekent uitkomst voor end-user. Onpraktisch.
            GUI met input-veld en resultaat-output waarschijnlijk het meest praktisch.
                Optie om zelf tekens te kiezen die geteld worden?
        Grote "Tel nu" knop?
        Tekst naar char array
        foreach door char array en counter++
        resultaat printen

        Toevoegingen:
        - Grid in window voor layout.
        - Achtergrondkleur voor overzicht.
        - Inputveld minimale grootte gegeven voor leesbaarheid. En een scrollbar.
        - Gekozen chars limiten op 1 char per veld.
        - Resize van window uitgezet, zodat de UI altijd goed zichtbaar is. En deze grootte is prima voor pc's.

        Tegengekomen problemen:
        - Kennisgebrek in welke velden ik moest programmeren. Eerst geprobeerd om dingen uit te voeren zodra tekst gewijzigd werd in
        een van de velden. Maar onpraktisch, want constant bewerkingen voor de computer als iemand in een input-veld een verhaal gaat typen.
        Uiteindelijk alle acties onder de Tel nu! knop gezet.
        - Moeite met de variatie in Content bij Label, Text bij TextBlock, en ??? bij RichTextBox. Raakte telkens in de war bij typen in XAML-code.
        - Er zit geen maximumgrootte aan de tekst die ingevoerd kan worden. Een A4 vol met i's bevat meer tekens dan een met W's.
        Char array zou een limiet kunnen krijgen. Maar dan moet ik ook feedback geven aan end-user dat de limiet bereikt is.
        Ik kom er niet uit hoe ik dat laatste moet doen, zonder een computerberekening per wijziging in input-veld te doen.
        */

        private void TelNu_Click(object sender, RoutedEventArgs e)
        {
            string rtbTekst = TekstVanRTB(Bronbestand);
            char[] teControleren = rtbTekst.ToCharArray();

            char controleerOp1 = Convert.ToChar(Character1.Text);
            char controleerOp2 = Convert.ToChar(Character2.Text);
            char controleerOp3 = Convert.ToChar(Character3.Text);
            char controleerOp4 = Convert.ToChar(Character4.Text);

            int gevonden1 = 0;
            int gevonden2 = 0;
            int gevonden3 = 0;
            int gevonden4 = 0;

            foreach (char teken in teControleren)
            {
                if (teken == controleerOp1)
                {
                    gevonden1++;
                }
                else if (teken == controleerOp2)
                {
                    gevonden2++;
                }
                else if (teken == controleerOp3)
                {
                    gevonden3++;
                }
                else if (teken == controleerOp4)
                {
                    gevonden4++;
                }
            }
            Label1.Content = "Deze tekst bevat " + gevonden1 + "x het teken " + controleerOp1;
            Label2.Content = "Deze tekst bevat " + gevonden2 + "x het teken " + controleerOp2;
            Label3.Content = "Deze tekst bevat " + gevonden3 + "x het teken " + controleerOp3;
            Label4.Content = "Deze tekst bevat " + gevonden4 + "x het teken " + controleerOp4;
        }
        public string TekstVanRTB(RichTextBox naam)
        {
            TextRange uitvoer = new TextRange(
                naam.Document.ContentStart,
                naam.Document.ContentEnd
                );
            return uitvoer.Text;
        }
    }
}
