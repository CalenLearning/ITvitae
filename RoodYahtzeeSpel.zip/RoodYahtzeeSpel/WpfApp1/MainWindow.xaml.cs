﻿using System;
using System.Linq;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /*
        Yahtzeeregels:
        5 dobbelstenen.
        2-4 spelers. Maar PDF zegt gebruiker. Dus 1?
        3x gooien per beurt (eerder stoppen mag)
        Dobbelstenen kunnen opzij gelegd worden zodat ze niet opnieuw gegooid worden in 2e/3e beurt, dit
        kan ook weer ongedaan worden gemaakt.
        Keuze kunnen maken onder welke optie de worp(en) geteld worden.

        13 mogelijke uitkomsten:
        alle 1en
        alle 2en
        alle 3en
        alle 4en
        alle 5en
        alle 6en    Als deze 6 catgorieën samen >63 zijn, dan +35 punten
        3 dezelfde, score is die 3 + restwaarde andere 2
        4 dezelfde, score is die 4 + restwaarde andere 1
        3 dezelfde en 2 dezelfde, is 25 punten
        4 opeenvolgende getallen is 30 punten
        5 opeenvolgende getallen is 40 punten
        5 dezelfde is 50 punten
            als men al een yahtzee heeft gekozen met 50 punten, dan kan een volgende yahtzee ook gebruikt worden
            voor 3 & 4 of a kind, full house, kleine straat, grote straat, chance of de betreffende #-waarde.
            Iedere tweede en meer yahtzee in hetzelfde spel geeft 100 bonuspunten.
        chance = som van de stenen, zonder voorwaardes aan welke getallen

        Schijnt ook mogelijk te zijn om een ongeldige combinatie toe te wijzen? Dat geeft 0 punten voor die combinatie.

        Werkwijze:
        1. Schets gemaakt van GUI in Paint
        2. Layout gemaakt en geoptimalizeerd in WPF
        3. Code schrijven voor onderdelen
        4. Waarde van stenen opslaan in array en oplopend sorteren op grootte.
        5. Functies toewijzen aan de verschillende knoppen om de uiteindelijk worp op te slaan.
        6. Kon geen eenvoudige manier vinden om de app te resetten.
        7. Uiteindelijk knoppen onzichtbaar gemaakt als er 3 worpen gedaan zijn. En er zijn maar 13 knoppen
        om de werpknop terug te krijgen. Dus 13 beurten.
        8. Wie het eerste 100 punten haalt is onpraktisch als je alleen speelt. Dus nu is het "probeer de
        hoogste score te halen".
        */

        public MainWindow()
        {
            InitializeComponent();
            Uitleg.Text =
                "1. Rol de stenen met de knop 'Rol Stenen'.\n" +
                "2. Kies welke stenen u wilt bewaren met de vinkjes.\n" +
                "3. De knop 'Rol stenen' rolt nu de overige stenen\n" +
                "4. U kunt maximaal 3 keer rollen per beurt.\n" +
                "5. Kies onder welke categorie u uw score wilt opslaan.\n" +
                "6. Als u meer dan 63 punten haalt in de eerste 6 categorieën, krijgt u 35 bonuspunten.\n" +
                "7. Als u meer dan 1 Yahtzee heeft, kunt u de tweede Yahtzee in een andere categorie invullen." +
                " En dan krijgt u ook 100 bonuspunten\n" +
                "8. Er zijn 13 categorieën, dus u krijgt 13 beurten.";
        }

        //Was het zat dat variables soms wel en soms niet buiten scope waren. Daarom heb ik alles maar hier neergezet.
        int steen1 = 0;
        int steen2 = 0;
        int steen3 = 0;
        int steen4 = 0;
        int steen5 = 0;
        int worp = 0;
        bool yahtzee = false;
        int score = 0;
        int eenTotZesBoven63Bonus = 0;
        int bonusScore = 0;

        private int RolSteen(int steenNummer)
        {
            //Wijs een pseudo-willekeurig nummer (van 1 t/m 6) toe aan de dobbelsteen.
            Random rnd = new Random();
            steenNummer = rnd.Next(1, 7);
            return steenNummer;
        }

        private void ButtonRolStenen_Click(object sender, RoutedEventArgs e)
        {
            //Pakte toevallig goed uit om ze na elkaar te laten randomiseren.
            //Schijnt dat random van de systeemklok afgeleid wordt?
            //Wijst willekeurig nummer toe en geef dit weer.
            //Was wel even zoeken hoe ik de status van de XAML-checkbox kon lezen.
            if (worp < 4)
            {
                if (Check1.IsChecked == false)
                {
                    steen1 = RolSteen(steen1);
                    LabelSteen1.Content = steen1;
                }
                if (Check2.IsChecked == false)
                {
                    steen2 = RolSteen(steen2);
                    LabelSteen2.Content = steen2;
                }
                if (Check3.IsChecked == false)
                {
                    steen3 = RolSteen(steen3);
                    LabelSteen3.Content = steen3;
                }
                if (Check4.IsChecked == false)
                {
                    steen4 = RolSteen(steen4);
                    LabelSteen4.Content = steen4;
                }
                if (Check5.IsChecked == false)
                {
                    steen5 = RolSteen(steen5);
                    LabelSteen5.Content = steen5;
                }
                worp++;
                if (worp == 3)
                {
                    ButtonRolStenen.Visibility = Visibility.Hidden;
                }
            }
            //Maak de StackPanel met de knoppen van de categorieën zichtbaar zodra worp > 1.
            StackPanelAntwoorden.Visibility = Visibility.Visible;
            //In theorie mogelijk om de beginwaardes (alle 0) te locken met checkboxes. Dus die moeten ook
            //onzichtbaar beginnen. Bij worp > 1 zijn de waardes != 0. Dus checkboxes mogen zichtbaar zijn.
            Check1.Visibility = Visibility.Visible;
            Check2.Visibility = Visibility.Visible;
            Check3.Visibility = Visibility.Visible;
            Check4.Visibility = Visibility.Visible;
            Check5.Visibility = Visibility.Visible;
        }

        private int[] ResultaatWorpen()
        {
            //Los array gemaakt zodat ik deze telkens kan hergebruiken voor een aantal knoppen.
            //Grappig om een array terug te gooien, ook.
            int[] resultaat = new int[5];
            resultaat[0] = steen1;
            resultaat[1] = steen2;
            resultaat[2] = steen3;
            resultaat[3] = steen4;
            resultaat[4] = steen5;
            Array.Sort(resultaat);
            return resultaat;
        }
        
        private int AantalStenenVanDitGetal(int getal)
        {
            //Telt hoeveel dobbelstenen van het gegeven getal zijn.
            int stenen = 0;
            foreach (int steen in ResultaatWorpen())
            {
                if (steen == getal)
                {
                    stenen++;
                }
            }
            BonusEenTmZes(stenen * getal);//Kijk of het al >63 voor 35 bonuspunten.
            //return aantal stenen van gegeven waarde, maal die waarde, want dat is de score van dat onderdeel.
            //Lastig beslissen of het beter is om die waarde in de knop te vermenigvuldigen, of de score terug te sturen.
            return stenen * getal;
        }

        private void Score(int getal)
        {
            //Verhoog score met getal, print daarna de score, reset vervolgens de inputs zodat de volgende beurt begint.
            score += getal;
            LabelScore.Text = "Uw score is: " + score + " en uw bonusscore is: " + bonusScore + ".";
            ResetStenen();
        }
        private void ResetStenen()
        {
            //Stenen met een waarde van 0 doen meestal niets voor de score.
            //Uitgezonderd 3, 4, 5 dezelfde en 2+3 dezelfde. Maar de categorie-knoppen worden pas zichtbaar na 1x rol.
            //En de startwaardes van 0 kunnen niet bewaard worden, ook worden de bestaande checked statussen naar false gezet.
            steen1 = 0;
            steen2 = 0;
            steen3 = 0;
            steen4 = 0;
            steen5 = 0;
            LabelSteen1.Content = "";
            LabelSteen2.Content = "";
            LabelSteen3.Content = "";
            LabelSteen4.Content = "";
            LabelSteen5.Content = "";
            Check1.IsChecked = false;
            Check2.IsChecked = false;
            Check3.IsChecked = false;
            Check4.IsChecked = false;
            Check5.IsChecked = false;
            StackPanelAntwoorden.Visibility = Visibility.Hidden;
            worp = 0;
            ButtonRolStenen.Visibility = Visibility.Visible;
        }

        private void BonusEenTmZes(int getal)
        {
            //Verhoog het totaal van de worpen in 1 t/m 6 met getal. If getal>63, voeg 35 aan bonusscore toe.
            eenTotZesBoven63Bonus += getal;
            if (eenTotZesBoven63Bonus > 63)
            {
                bonusScore += 35;
            }
        }

        private bool MeerdereYahtzee()
        {
            //Kijkt of er al een eerste yahtzee was.
            //Kijkt of de waardes van de huidige worp ook yahtzee zijn.
            //If beide true, return true, zodat die gebruikt kan worden onder alle knoppen.
            bool opnieuwYahtzee = false;
            int[] resultaat = ResultaatWorpen();
            if (yahtzee && (resultaat[0] == resultaat[4]))
            {
                opnieuwYahtzee = true;
            }
            return opnieuwYahtzee;
        }

        //Hieronder staan de buttons.
        private void ButtonAlle1_Click(object sender, RoutedEventArgs e)
        {
            //Extra regel omdat het anders label.content = method en score(method) wordt.
            //Dit scheelt berekeningen, denk ik?
            if (MeerdereYahtzee() && steen1 == 1) //Zodat een yahtzee met tweeën ongeldig is.
            {
                bonusScore += 100;
            }
            int getal = AantalStenenVanDitGetal(1);     //Vraag score op, op basis van aantal stenen met gegeven getal.
            LabelAlle1.Content = getal;                 //Print score op dit onderdeel.
            Score(getal);                               //Verhoog totaalscore en print dit.
            ButtonAlle1.Visibility = Visibility.Hidden; //Maak knop om deze categorie te kiezen onzichtbaar.
        }

        private void ButtonAlle2_Click(object sender, RoutedEventArgs e)
        {
            if (MeerdereYahtzee() && steen1 == 2)
            {
                bonusScore += 100;
            }
            int getal = AantalStenenVanDitGetal(2);
            LabelAlle2.Content = getal;
            Score(getal);
            ButtonAlle2.Visibility = Visibility.Hidden;
        }

        private void ButtonAlle3_Click(object sender, RoutedEventArgs e)
        {
            if (MeerdereYahtzee() && steen1 == 3)
            {
                bonusScore += 100;
            }
            int getal = AantalStenenVanDitGetal(3);
            LabelAlle3.Content = getal;
            Score(getal);
            ButtonAlle3.Visibility = Visibility.Hidden;
        }

        private void ButtonAlle4_Click(object sender, RoutedEventArgs e)
        {
            if (MeerdereYahtzee() && steen1 == 4)
            {
                bonusScore += 100;
            }
            int getal = AantalStenenVanDitGetal(4);
            LabelAlle4.Content = getal;
            Score(getal);
            ButtonAlle4.Visibility = Visibility.Hidden;
        }

        private void ButtonAlle5_Click(object sender, RoutedEventArgs e)
        {
            if (MeerdereYahtzee() && steen1 == 5)
            {
                bonusScore += 100;
            }
            int getal = AantalStenenVanDitGetal(5);
            LabelAlle5.Content = getal;
            Score(getal);
            ButtonAlle5.Visibility = Visibility.Hidden;
        }

        private void ButtonAlle6_Click(object sender, RoutedEventArgs e)
        {
            if (MeerdereYahtzee() && steen1 == 6)
            {
                bonusScore += 100;
            }
            int getal = AantalStenenVanDitGetal(6);
            LabelAlle6.Content = getal;
            Score(getal);
            ButtonAlle6.Visibility = Visibility.Hidden;
        }

        private void ButtonDrieZelfde_Click(object sender, RoutedEventArgs e)
        {
            //Ik kwam er aanvankelijk niet uit hoe ik dat kon doen. Vond online een geneste
            //for-loop bij een ander die een Yahtzee-spel maakte. Maar dat is "knip- en
            //plakwerk van andere projecten"? Dus hiermee verder gegaan.
            //Dit werkt wel, maar als er een 6e dobbelsteen bijkomt, heb ik een probleem.

            //Het sorteert de dobbelstenen eerst in ResultaatWorpen().
            //Dus als [0] == [2], is [1] hetzelfde getal, dus 3 hetzelfde.
            //Er zijn vijf dobbelstenen, dus 3 situaties waarin 3 getallen hetzelfde zijn.
            //Als 3 dobbelstenen niet gelijk zijn, blijft de waarde 0, want ongeldige score.
            int[] resultaat = ResultaatWorpen();
            int stenen = 0;
            if (resultaat[0] == resultaat[2] ||
                resultaat[1] == resultaat[3] ||
                resultaat[2] == resultaat[4])
            {
                stenen = resultaat.Sum();
            }
            if (MeerdereYahtzee())
            {
                bonusScore += 100;
            }
            LabelDrieZelfde.Content = stenen;
            Score(stenen);
            ButtonDrieZelfde.Visibility = Visibility.Hidden;
        }

        private void ButtonVierZelfde_Click(object sender, RoutedEventArgs e)
        {
            int[] resultaat = ResultaatWorpen();
            int stenen = 0;
            if (resultaat[0] == resultaat[3] ||
                resultaat[1] == resultaat[4])
            {
                stenen = resultaat.Sum();
            }
            if (MeerdereYahtzee())
            {
                bonusScore += 100;
            }
            LabelVierZelfde.Content = stenen;
            Score(stenen);
            ButtonVierZelfde.Visibility = Visibility.Hidden;
        }

        private void ButtonDrieEnTweeZelfde_Click(object sender, RoutedEventArgs e)
        {
            int stenen = 0;
            int[] resultaat = ResultaatWorpen();
            if (resultaat[0] == resultaat[1] && resultaat[2] == resultaat[4] ||
                resultaat[0] == resultaat[2] && resultaat[3] == resultaat[4])
            {
                stenen = 25;
            }
            if (MeerdereYahtzee())
            {
                bonusScore += 100;
            }
            LabelDrieEnTweeZelfde.Content = stenen;
            Score(stenen);
            ButtonDrieEnTweeZelfde.Visibility = Visibility.Hidden;
        }

        private void ButtonVierOpeenvolgend_Click(object sender, RoutedEventArgs e)
        {
            int stenen = 0;
            int[] resultaat = ResultaatWorpen();
            if (resultaat[0] + 1 == resultaat[1] && resultaat[1] + 1 == resultaat[2] && resultaat[2] + 1 == resultaat[3] ||
                resultaat[1] + 1 == resultaat[2] && resultaat[2] + 1 == resultaat[3] && resultaat[3] + 1 == resultaat[4])
            {
                stenen = 30;
            }
            if (MeerdereYahtzee())
            {
                stenen = 30;
                bonusScore += 100;
            }
            LabelVierOpeenvolgend.Content = stenen;
            Score(stenen);
            ButtonVierOpeenvolgend.Visibility = Visibility.Hidden;
        }

        private void ButtonVijfOpeenvolgend_Click(object sender, RoutedEventArgs e)
        {
            int stenen = 0;
            int[] resultaat = ResultaatWorpen();
            if (resultaat[0] + 1 == resultaat[1] && resultaat[1] + 1 == resultaat[2] && resultaat[2] + 1 == resultaat[3] && resultaat[3] + 1 == resultaat[4])
            {
                stenen = 40;
            }
            if (MeerdereYahtzee())
            {
                stenen = 40;
                bonusScore += 100;
            }
            LabelVijfOpeenvolgend.Content = stenen;
            Score(stenen);
            ButtonVijfOpeenvolgend.Visibility = Visibility.Hidden;
        }

        private void ButtonVijfDezelfde_Click(object sender, RoutedEventArgs e)
        {
            int[] resultaat = ResultaatWorpen();
            int stenen = 0;
            if (resultaat[0] == resultaat[4])
            {
                stenen = 50;
                //Zet de bool yahtzee naar true. Die kan ik dan elders gebruiken om 2e yahtzee en meer te detecteren.
                yahtzee = true;
            }
            LabelVijfDezelfde.Content = stenen;
            Score(stenen);
            ButtonVijfDezelfde.Visibility = Visibility.Hidden;
        }

        private void ButtonVijfWillekeurig_Click(object sender, RoutedEventArgs e)
        {
            int stenen = steen1 + steen2 + steen3 + steen4 + steen5;
            LabelVijfWillekeurig.Content = stenen;
            Score(stenen);
            ButtonVijfWillekeurig.Visibility = Visibility.Hidden;
        }
    }
}
